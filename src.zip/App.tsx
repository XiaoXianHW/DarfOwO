import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, Code2, Cpu, PenTool, Sparkles, Layers, Github, Mail, Send, Twitter, MessageSquare, Music, MessageCircle, Tv, Palette, Box, ArrowLeft, X, BookOpen, GitBranch, Layout, Camera, Heart, Coffee, Monitor, Smartphone, Activity, Headphones, Users, ChevronRight } from 'lucide-react';

export default function App() {
  const [hoveredSide, setHoveredSide] = useState<'side1' | 'side2' | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const [is3D, setIs3D] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [heartRate, setHeartRate] = useState(72);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Simulate live heart rate
  useEffect(() => {
    if (!isProfileOpen) return;
    const interval = setInterval(() => {
      setHeartRate(prev => {
        const change = Math.floor(Math.random() * 5) - 2; // -2 to +2
        const newRate = prev + change;
        return Math.min(Math.max(newRate, 60), 100); // Keep between 60 and 100
      });
    }, 2000);
    return () => clearInterval(interval);
  }, [isProfileOpen]);

  // Calculate dynamic positions for the split
  const getClips = () => {
    if (isMobile) {
      let left = 50, right = 50;
      if (hoveredSide === 'side1') { left = 92; right = 88; }
      if (hoveredSide === 'side2') { left = 8; right = 12; }
      return {
        clip1: `polygon(0% 0%, 100% 0%, 100% ${right}%, 0% ${left}%)`,
        clip2: `polygon(0% ${left}%, 100% ${right}%, 100% 100%, 0% 100%)`,
        divider: `polygon(0% calc(${left}% - 1px), 100% calc(${right}% - 1px), 100% calc(${right}% + 1px), 0% calc(${left}% + 1px))`
      };
    } else {
      let top = 50, bottom = 50;
      if (hoveredSide === 'side1') { top = 85; bottom = 75; }
      if (hoveredSide === 'side2') { top = 15; bottom = 25; }
      return {
        clip1: `polygon(0% 0%, ${top}% 0%, ${bottom}% 100%, 0% 100%)`,
        clip2: `polygon(${top}% 0%, 100% 0%, 100% 100%, ${bottom}% 100%)`,
        divider: `polygon(calc(${top}% - 1px) 0%, calc(${top}% + 1px) 0%, calc(${bottom}% + 1px) 100%, calc(${bottom}% - 1px) 100%)`
      };
    }
  };

  const { clip1, clip2, divider } = getClips();

  const getAvatarAnim = () => {
    if (!hoveredSide) {
      return {
        top: isMobile ? '15%' : '12%',
        left: '50%',
        x: '-50%',
        y: '-50%',
        scale: isMobile ? 0.5 : 0.6,
        rotate: 0,
      };
    }
    if (hoveredSide === 'side1') {
      return {
        top: isMobile ? '85%' : '50%',
        left: isMobile ? '50%' : '80%',
        x: '-50%',
        y: '-50%',
        scale: isMobile ? 0.6 : 1,
        rotate: 3,
      };
    }
    if (hoveredSide === 'side2') {
      return {
        top: isMobile ? '15%' : '50%',
        left: isMobile ? '50%' : '20%',
        x: '-50%',
        y: '-50%',
        scale: isMobile ? 0.6 : 1,
        rotate: -3,
      };
    }
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden font-sans bg-[#0f172a]">
      
      {/* STATIC BACKGROUND LAYER */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        {/* Side 1 Background */}
        <motion.div 
          className="absolute inset-0 bg-[#020617]"
          animate={{ clipPath: clip1 }}
          transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
        >
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(#22d3ee 1px, transparent 1px), linear-gradient(90deg, #22d3ee 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        </motion.div>
        
        {/* Side 2 Background */}
        <motion.div 
          className="absolute inset-0 bg-slate-50"
          animate={{ clipPath: clip2 }}
          transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
        >
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle, #000 2px, transparent 2px)', backgroundSize: '32px 32px' }} />
        </motion.div>

        {/* Divider Line */}
        <motion.div
          className="absolute inset-0 z-10"
          animate={{ 
            clipPath: divider,
            backgroundColor: hoveredSide === 'side1' ? '#22d3ee' : hoveredSide === 'side2' ? '#fb923c' : '#ffffff',
            opacity: is3D ? 0 : 1
          }}
          style={{ filter: 'drop-shadow(0 0 10px currentColor)' }}
          transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
        />
      </div>

      {/* 3D COMPONENTS LAYER */}
      <div className="absolute inset-0 z-10" style={{ perspective: '1500px' }}>
        <motion.div 
          className="w-full h-full relative"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* SIDE 2 CARD: RIGHT/BOTTOM (Design / Sensibility / Light Theme) */}
          <motion.div 
            className="absolute inset-0 z-10 flex items-center justify-center p-0 sm:p-8 pointer-events-none"
            animate={{ clipPath: clip2 }}
            transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
          >
            <motion.div 
              className="relative w-full max-w-[1800px] h-full sm:h-[85vh] sm:min-h-[600px] sm:rounded-2xl pointer-events-auto cursor-pointer sm:cursor-default"
              onMouseEnter={() => setHoveredSide('side2')}
              onClick={() => isMobile && setHoveredSide('side2')}
              onMouseLeave={() => setHoveredSide(null)}
              animate={{
                rotateY: is3D && !isMobile ? -8 : 0,
                rotateX: is3D && isMobile ? 8 : 0,
                z: is3D ? 50 : 0
              }}
              style={{ transformOrigin: isMobile ? 'top center' : 'left center', transformStyle: 'preserve-3d' }}
              transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
            >
              {/* Content Container */}
              <motion.div
                className="absolute inset-0 flex flex-col p-6 pt-[15vh] pb-32 sm:pt-16 sm:p-16 lg:pr-32 overflow-hidden"
                animate={{
                  opacity: hoveredSide === 'side1' ? (isMobile ? 0 : 0.2) : 1,
                  scale: hoveredSide === 'side1' ? 0.95 : hoveredSide === 'side2' ? 1.02 : 1,
                  x: hoveredSide === 'side1' ? (isMobile ? 0 : 40) : 0,
                  y: hoveredSide === 'side1' ? (isMobile ? 20 : 0) : 0,
                }}
                transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
              >
                {/* Abstract Background Typography */}
                <div className="absolute -right-10 top-1/4 text-[80px] sm:text-[200px] font-serif italic text-orange-900/5 whitespace-nowrap pointer-events-none select-none">
                  Sensibility
                </div>
                
                <div className="relative z-10 w-full max-w-lg flex flex-col items-end text-right ml-auto h-full justify-center">
                  {/* Header Section */}
                  <div className="flex flex-col items-end mb-8">
                    <Palette className="w-10 h-10 sm:w-12 sm:h-12 text-orange-500 mb-4 sm:mb-6" strokeWidth={1.5} />
                    <h2 className="text-3xl sm:text-6xl font-serif italic tracking-tight text-slate-900 mb-4 sm:mb-6">
                      Crafting <br/><span className="font-sans font-bold text-orange-600 not-italic">Experiences</span>
                    </h2>
                  </div>

                  {/* Outline List */}
                  <div className="flex flex-col items-end space-y-4 mb-8 w-full">
                    {[
                      { icon: Sparkles, title: '个人OC介绍' },
                      { icon: PenTool, title: '创作型技能' },
                      { icon: Heart, title: '性格及个人简介' },
                      { icon: Palette, title: '艺术性作品' },
                      { icon: Coffee, title: '随笔&生活类博客' }
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-3 text-slate-700 hover:text-orange-600 transition-colors cursor-pointer group flex-row-reverse">
                        <item.icon className="w-5 h-5 text-orange-500 group-hover:scale-110 transition-transform" />
                        <span className="font-bold font-sans text-sm sm:text-base tracking-wide">{item.title}</span>
                      </div>
                    ))}
                  </div>
                  
                  {/* Enter Button */}
                  <button 
                    className="px-6 py-3 border-2 border-orange-500 text-orange-600 rounded-full font-mono text-xs sm:text-sm font-bold hover:bg-orange-500 hover:text-white transition-colors pointer-events-auto shadow-lg shadow-orange-500/20 w-fit"
                    onClick={(e) => { e.stopPropagation(); window.open('https://arcyuan.cn', '_blank'); }}
                  >
                    ARCYUAN.CN
                  </button>
                </div>
              </motion.div>

              {/* Glass Overlay for Side 2 */}
              <motion.div
                className="absolute inset-0 bg-white/40 backdrop-blur-xl z-20 pointer-events-none"
                initial={{ opacity: 0 }}
                animate={{ opacity: hoveredSide === 'side1' ? 1 : 0 }}
                transition={{ duration: 0.5 }}
              />
            </motion.div>
          </motion.div>

          {/* SIDE 1 CARD: LEFT/TOP (Geek / Rationality / Dark Theme) */}
          <motion.div 
            className="absolute inset-0 z-20 flex items-center justify-center p-0 sm:p-8 pointer-events-none"
            animate={{ clipPath: clip1 }}
            transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
          >
            <motion.div 
              className="relative w-full max-w-[1800px] h-full sm:h-[85vh] sm:min-h-[600px] sm:rounded-2xl pointer-events-auto cursor-pointer sm:cursor-default"
              onMouseEnter={() => setHoveredSide('side1')}
              onClick={() => isMobile && setHoveredSide('side1')}
              onMouseLeave={() => setHoveredSide(null)}
              animate={{
                rotateY: is3D && !isMobile ? 8 : 0,
                rotateX: is3D && isMobile ? -8 : 0,
                z: is3D ? 50 : 0
              }}
              style={{ transformOrigin: isMobile ? 'bottom center' : 'right center', transformStyle: 'preserve-3d' }}
              transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
            >
              {/* Content Container */}
              <motion.div
                className="absolute inset-0 flex flex-col p-6 pt-12 pb-[15vh] sm:pb-16 sm:p-16 lg:pl-32 overflow-hidden"
                animate={{
                  opacity: hoveredSide === 'side2' ? (isMobile ? 0 : 0.2) : 1,
                  scale: hoveredSide === 'side2' ? 0.95 : hoveredSide === 'side1' ? 1.02 : 1,
                  x: hoveredSide === 'side2' ? (isMobile ? 0 : -40) : 0,
                  y: hoveredSide === 'side2' ? (isMobile ? -20 : 0) : 0,
                }}
                transition={{ type: 'spring', bounce: 0.2, duration: 0.8 }}
              >
                <div className="relative z-10 w-full max-w-lg flex flex-col h-full justify-center">
                  {/* Header Section */}
                  <div className="flex flex-col items-start text-left mb-8">
                    <Terminal className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-400 mb-4 sm:mb-6" strokeWidth={1.5} />
                    <div className="font-mono text-slate-300 text-xs sm:text-base leading-relaxed bg-black/60 p-4 sm:p-6 rounded-xl border border-cyan-900/50 w-full shadow-inner text-left backdrop-blur-sm">
                      <span className="text-pink-500">const</span> <span className="text-blue-400">developer</span> = {'{'}
                      <br/>
                      &nbsp;&nbsp;name: <span className="text-green-400">"Arc"</span>,
                      <br/>
                      &nbsp;&nbsp;role: <span className="text-green-400">"Software Engineer"</span>,
                      <br/>
                      &nbsp;&nbsp;status: <span className="text-green-400">"Compiling..."</span>
                      <br/>
                      {'}'};
                    </div>
                  </div>

                  {/* Outline List */}
                  <div className="flex flex-col items-start space-y-4 mb-8 w-full">
                    {[
                      { icon: Cpu, title: '个人技术栈' },
                      { icon: GitBranch, title: '维护的项目' },
                      { icon: Terminal, title: '技术性博客' },
                      { icon: Users, title: '合作开发者' }
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-3 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer group">
                        <item.icon className="w-5 h-5 text-cyan-500 group-hover:scale-110 transition-transform" />
                        <span className="font-bold font-mono text-sm sm:text-base tracking-wide">{item.title}</span>
                      </div>
                    ))}
                  </div>

                  {/* Enter Button */}
                  <button 
                    className="px-6 py-3 border-2 border-cyan-500 text-cyan-400 rounded-full font-mono text-xs sm:text-sm font-bold hover:bg-cyan-500 hover:text-slate-900 transition-colors pointer-events-auto shadow-lg shadow-cyan-500/20 w-fit"
                    onClick={(e) => { e.stopPropagation(); window.open('https://darf.dev', '_blank'); }}
                  >
                    DARF.DEV
                  </button>
                </div>
              </motion.div>

              {/* Glass Overlay for Side 1 */}
              <motion.div
                className="absolute inset-0 bg-[#020617]/60 backdrop-blur-xl z-20 pointer-events-none"
                initial={{ opacity: 0 }}
                animate={{ opacity: hoveredSide === 'side2' ? 1 : 0 }}
                transition={{ duration: 0.5 }}
              />
            </motion.div>
          </motion.div>

          {/* LIVE2D PLACEHOLDER (Center Image) */}
          <motion.div
            className="fixed z-50 pointer-events-none flex items-center justify-center"
            animate={{
              ...getAvatarAnim(),
              z: is3D ? 100 : 0
            }}
            transition={{ type: 'spring', bounce: 0.3, duration: 0.8 }}
          >
            {/* Biological Breathing/Floating Animation Wrapper */}
            <motion.div
              animate={{
                y: [-10, 10, -10],
                rotateZ: [-2, 2, -2],
                scale: [1, 1.02, 1],
              }}
              transition={{
                repeat: Infinity,
                duration: 4,
                ease: "easeInOut"
              }}
              className="relative w-32 h-32 sm:w-48 sm:h-48 lg:w-64 lg:h-64"
            >
              {/* Default Avatar */}
              <motion.div
                className="absolute inset-0 cursor-pointer group"
                animate={{ opacity: (!hoveredSide && !isProfileOpen) ? 1 : 0 }}
                transition={{ duration: 0.4 }}
                onClick={() => !hoveredSide && setIsProfileOpen(true)}
                style={{ pointerEvents: (!hoveredSide && !isProfileOpen) ? 'auto' : 'none' }}
              >
                <img
                  src="https://static.xiaoxian.org/DarfOwO.jpg"
                  alt="Default Avatar"
                  className="w-full h-full object-cover rounded-full border-[3px] border-white/50 shadow-2xl shadow-black/20"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-sm">
                  <span className="text-white font-mono text-xs font-bold text-center px-2">
                    [ REVEAL ]<br/>SOUL
                  </span>
                </div>
              </motion.div>
              {/* Side 1 Avatar (Left) */}
              <motion.img
                src="https://static.xiaoxian.org/Darf.jpg"
                alt="Rationality Avatar"
                animate={{ opacity: hoveredSide === 'side1' ? 1 : 0 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 w-full h-full object-cover rounded-full border-[3px] border-cyan-400 shadow-2xl shadow-cyan-500/50"
                referrerPolicy="no-referrer"
              />
              {/* Side 2 Avatar (Right) */}
              <motion.img
                src="https://static.xiaoxian.org/DeepArc.png"
                alt="Sensibility Avatar"
                animate={{ opacity: hoveredSide === 'side2' ? 1 : 0 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 w-full h-full object-cover rounded-full border-[3px] border-orange-400 shadow-2xl shadow-orange-500/50"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </motion.div>

        </motion.div>
      </div>

      {/* FOOTER & CONTROLS (Always on top, flat) */}
      <div className="fixed bottom-4 sm:bottom-8 w-full px-4 sm:px-8 flex flex-col sm:flex-row justify-center sm:justify-between items-center gap-4 sm:gap-0 z-[60] pointer-events-none mix-blend-difference text-white">
        
        {/* Copyright */}
        <div className="text-xs sm:text-sm font-mono text-center sm:text-left order-2 sm:order-1 opacity-70">
          © 2026 Arc. All rights reserved.
        </div>

        {/* Social Icons */}
        <div className="flex flex-wrap gap-4 pointer-events-auto justify-center order-1 sm:order-3 opacity-70">
          <a href="#" target="_blank" rel="noreferrer" title="QQ" className="hover:opacity-100 transition-opacity"><MessageCircle className="w-5 h-5" /></a>
          <a href="#" target="_blank" rel="noreferrer" title="Bilibili" className="hover:opacity-100 transition-opacity"><Tv className="w-5 h-5" /></a>
          <a href="#" target="_blank" rel="noreferrer" title="GitHub" className="hover:opacity-100 transition-opacity"><Github className="w-5 h-5" /></a>
          <a href="#" target="_blank" rel="noreferrer" title="Email" className="hover:opacity-100 transition-opacity"><Mail className="w-5 h-5" /></a>
          <a href="#" target="_blank" rel="noreferrer" title="Telegram" className="hover:opacity-100 transition-opacity"><Send className="w-5 h-5" /></a>
          <a href="#" target="_blank" rel="noreferrer" title="X (Twitter)" className="hover:opacity-100 transition-opacity"><Twitter className="w-5 h-5" /></a>
          <a href="#" target="_blank" rel="noreferrer" title="Discord" className="hover:opacity-100 transition-opacity"><MessageSquare className="w-5 h-5" /></a>
          <a href="#" target="_blank" rel="noreferrer" title="Netease Cloud Music" className="hover:opacity-100 transition-opacity"><Music className="w-5 h-5" /></a>
        </div>
      </div>

      {/* TOP CONTROLS */}
      {/* Legacy Portal */}
      <div className="fixed top-6 left-6 pointer-events-auto z-[60] mix-blend-difference text-white">
        <a
          href="https://v2.xiaoxian.org"
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-center w-10 h-10 rounded-full transition-all duration-300 opacity-70 hover:opacity-100 hover:bg-white/10"
          title="Legacy Portal"
        >
          <ArrowLeft className="w-5 h-5" />
        </a>
      </div>

      {/* 3D Toggle Button (Desktop Only) */}
      {!isMobile && (
        <div className="fixed top-6 right-6 pointer-events-auto z-[60] mix-blend-difference text-white flex items-center gap-3">
          <span className="font-mono text-xs opacity-70 uppercase tracking-widest hidden sm:block">Toggle Dimension</span>
          <button
            onClick={() => setIs3D(!is3D)}
            title="Toggle 3D"
            className={`p-2 rounded-full transition-all duration-300 opacity-70 hover:opacity-100 hover:bg-white/10 ${is3D ? 'ring-2 ring-white' : ''}`}
          >
            <Box className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* BOTTOM TAGLINE */}
      <div className={`fixed bottom-24 sm:bottom-12 left-1/2 -translate-x-1/2 z-[50] pointer-events-none text-center transition-opacity duration-500 mix-blend-difference text-white ${hoveredSide ? 'opacity-0' : 'opacity-100'}`}>
        <p className="font-serif italic text-lg sm:text-xl tracking-widest opacity-70">
          Two Realms, One Soul.
        </p>
        <p className="font-mono text-xs sm:text-sm mt-2 tracking-widest uppercase opacity-50">
          Choose Your Perspective
        </p>
      </div>

      {/* PROFILE OVERLAY */}
      <AnimatePresence>
        {isProfileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[100] flex items-center justify-center p-0 sm:p-8 pointer-events-auto"
          >
            {/* Acrylic Blur Background */}
            <div className="absolute inset-0 bg-white/5 dark:bg-black/20 backdrop-blur-2xl backdrop-saturate-150" onClick={() => setIsProfileOpen(false)}>
              {/* Subtle noise texture */}
              <div className="absolute inset-0 opacity-[0.03] mix-blend-overlay" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}></div>
            </div>
            
            <motion.div
              initial={{ scale: 0.95, y: 10, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 10, opacity: 0 }}
              className="relative w-full max-w-[1200px] h-full sm:h-[80vh] sm:min-h-[600px] sm:rounded-3xl bg-white/10 dark:bg-black/40 backdrop-blur-3xl border border-white/20 shadow-2xl overflow-y-auto sm:overflow-hidden flex flex-col sm:flex-row"
            >
              <button 
                onClick={() => setIsProfileOpen(false)}
                className="absolute top-6 right-6 z-50 text-white/70 hover:text-white transition-colors bg-black/20 hover:bg-black/40 p-2 rounded-full backdrop-blur-md"
              >
                <X className="w-5 h-5" />
              </button>
              
              {/* Left Column: Profile Info */}
              <div className="w-full sm:w-1/3 p-8 sm:p-12 border-b sm:border-b-0 sm:border-r border-white/10 flex flex-col shrink-0 bg-black/20">
                <img src="https://static.xiaoxian.org/DarfOwO.jpg" alt="Arc" className="w-24 h-24 rounded-2xl border border-white/20 mb-6 shadow-lg object-cover" referrerPolicy="no-referrer" />
                <h2 className="text-3xl sm:text-4xl font-bold text-white mb-2 tracking-tight">Arc</h2>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-mono text-white/80 border border-white/5">INFJ-A</span>
                  <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-mono text-white/80 border border-white/5">Developer</span>
                  <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-mono text-white/80 border border-white/5">Designer</span>
                </div>
                <p className="text-white/70 text-sm leading-relaxed mb-8">
                  I exist at the intersection of rigorous logic and boundless creativity. Navigating the world through multiple lenses, constantly seeking the underlying patterns that connect disparate ideas.
                </p>
              </div>

              {/* Right Column: Entry Points */}
              <div className="w-full sm:w-2/3 p-8 sm:p-12 sm:overflow-y-auto custom-scrollbar shrink-0 sm:shrink flex flex-col justify-center">
                <h3 className="text-white/50 font-mono text-sm uppercase tracking-widest mb-8">Explore Dimensions</h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Life */}
                  <div className="group cursor-pointer bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-6 transition-all duration-300 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-orange-500/20 text-orange-400 rounded-xl group-hover:scale-110 transition-transform">
                        <Coffee className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">生活 (Life)</h4>
                        <p className="text-white/50 text-xs mt-1">Daily moments & essays</p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white/70 transition-colors" />
                  </div>

                  {/* Social */}
                  <div className="group cursor-pointer bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-6 transition-all duration-300 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl group-hover:scale-110 transition-transform">
                        <MessageCircle className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">社交 (Social)</h4>
                        <p className="text-white/50 text-xs mt-1">Connect & interact</p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white/70 transition-colors" />
                  </div>

                  {/* Devices */}
                  <div className="group cursor-pointer bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-6 transition-all duration-300 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-slate-500/20 text-slate-300 rounded-xl group-hover:scale-110 transition-transform">
                        <Monitor className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">设备 (Devices)</h4>
                        <p className="text-white/50 text-xs mt-1">Gear & workspace</p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white/70 transition-colors" />
                  </div>

                  {/* Music */}
                  <div className="group cursor-pointer bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-6 transition-all duration-300 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-purple-500/20 text-purple-400 rounded-xl group-hover:scale-110 transition-transform">
                        <Music className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">音乐 (Music)</h4>
                        <p className="text-white/50 text-xs mt-1">Playlists & vibes</p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white/70 transition-colors" />
                  </div>

                  {/* Status */}
                  <div className="group cursor-pointer bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-6 transition-all duration-300 flex items-center justify-between sm:col-span-2">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-green-500/20 text-green-400 rounded-xl group-hover:scale-110 transition-transform">
                        <Activity className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">状态 (Status)</h4>
                        <p className="text-white/50 text-xs mt-1">Live metrics & current activity</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right hidden sm:block">
                        <p className="text-white font-mono text-sm">{heartRate} bpm</p>
                        <p className="text-white/50 text-xs">Heart Rate</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white/70 transition-colors" />
                    </div>
                  </div>

                </div>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
